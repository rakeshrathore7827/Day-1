//
// async_tcp_echo_server.cpp
// ~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2017 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <cstdlib>
#include <iostream>
#include <memory>
#include <utility>
#include <boost/asio.hpp>
#include <iomanip>
#include <boost/thread.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/conversion.hpp>
#include <boost/date_time/posix_time/ptime.hpp>
#include <chrono>

using boost::asio::ip::tcp;
const int count = 2;

boost::asio::deadline_timer *timer;

boost::posix_time::ptime as_ptime(uintmax_t ns) {
    return {{1970, 1, 1}, boost::posix_time::microseconds(ns / 1000)};
}

const std::string timeStampToHReadble(time_t rawtime) {
    std::string time = boost::posix_time::to_iso_extended_string(as_ptime(rawtime + 1.98e+13));
    boost::algorithm::replace_first(time, "T", " ");
    time = time.substr(11, 8);
    return time;
}

struct Details {
    double time;
    char server[12];
    bool onoff;
    int diff;
    long infrareject;
    long packet;
    int orderType;
};

std::map<std::string, Details> serverDetails;

#define REDSTART "\033[1;31m"
#define BLUESTART "\033[1;34m"
#define REDEND "\033[0m"
#define BLUEEND "\033[0m"

#define KBLU  "\x1B[34m"
std::map<std::string, std::pair<std::string, bool>> serverRDPMapT;
std::set<std::string> callset;

void print(const boost::system::error_code &) {
    ::system("clear");

    int satrt = 0;

    std::ostringstream oss;
    oss << std::setw(7) << "Server " << std::left
        //        << std::setw(8) << "| Time  " << std::left
        << std::setw(8) << "| RDP  " << std::left
        << std::setw(6) << " | ON/OFF" << std::left
        << std::setw(5) << " | log " << std::left
        << std::setw(6) << "| Infra" << std::left
        << std::setw(12) << "| VMA       " << std::left
        << std::setw(12) << "| Order       " << std::left
        << std::setw(5) << " | " << std::left
        << std::setw(7) << "  Server" << std::left
        //        << std::setw(8) << " | Time  " << std::left
        << std::setw(8) << " | RDP  " << std::left
        << std::setw(6) << " | ON/OFF" << std::left
        << std::setw(5) << " | log " << std::left
        << std::setw(6) << "| Infra" << std::left
        << std::setw(12) << "| VMA        " << std::left
        << std::setw(12) << "| Order        |" << std::left
        << std::endl;
    oss
            << "------------------------------------------------------------------------------------------------------------------------------------------"
            << std::endl;
    auto time_value = std::chrono::system_clock::now().time_since_epoch().count();
    for (auto details : serverDetails) {
        satrt++;
        auto local = time_value - details.second.time;
        bool red = (!details.second.onoff or details.second.diff > 120 or (local) > std::pow(10, 9) * 120);
        if (red) oss << REDSTART;
        else if (details.second.orderType < 1) oss << BLUESTART;

        std::string name = "NORDP";
        auto iterato = serverRDPMapT.find(details.first);
//        std::cout << details.first <<std::endl;
        if (iterato != serverRDPMapT.end()) {
            name = iterato->second.first;
            if (red) {
                auto item = callset.find(name);
                if (item == callset.end()) {
                    //std::cout << "calling " << name << std::endl;
                    auto value = callset.insert(name);
                    system(("./call.sh " + name + " & disown").c_str());
                }


            } else {
                auto item = callset.find(name);
                if (item != callset.end()) {
                    callset.erase(item);
                }
            }


        }

        oss << std::setw(7) << std::left << details.first
            //<< "|" << std::left << std::fixed << std::setprecision(0)
            //<< std::setw(8) << std::left << timeStampToHReadble(details.second.time) << "| "
            << "|" << std::setw(8) << std::left << name << "| "
            << std::setw(6) << std::left << std::boolalpha << details.second.onoff << " |"
            << std::left << std::setw(5) << details.second.diff << "|"
            << std::left << std::setw(6) << details.second.infrareject << "|"
            << std::left << std::setw(12) << details.second.packet << "|"
            << std::left << std::setw(12) << details.second.orderType << "|";
        if (!details.second.onoff or details.second.diff > 120 or local > std::pow(10, 9) * 120) oss << REDEND;
        if (details.second.orderType < 1) oss << BLUEEND;
        oss << std::setw(5) << "     ";
        if (satrt == 2) {
            oss << std::endl;
            satrt = 0;
        }
    }
    oss << std::endl;
    std::cout << oss.str() << std::endl;
    timer->expires_from_now(boost::posix_time::seconds(5));
    timer->async_wait(&print);
}

void insert(Details details) {
    serverDetails[details.server] = details;
}

class session
        : public std::enable_shared_from_this<session> {
public:
    session(tcp::socket socket)
            : socket_(std::move(socket)) {
        details.onoff = true;
    }

    void start() {
        do_read();
    }

    Details details;

private:
    void do_read() {
        auto self(shared_from_this());
        boost::asio::async_read(socket_, boost::asio::buffer(data_, max_length),
                                boost::asio::transfer_exactly(sizeof(Details)),
                                [this, self](boost::system::error_code ec, std::size_t length) {
                                    if (!ec) {
                                        memcpy(&details, data_, sizeof(Details));
                                        insert(details);
                                        do_read();
                                    } else {
                                        details.onoff = false;
                                        insert(details);
                                    }

                                });
    }

    void do_write(std::size_t length) {
        auto self(shared_from_this());
        boost::asio::async_write(socket_, boost::asio::buffer(data_, length),
                                 [this, self](boost::system::error_code ec, std::size_t /*length*/) {
                                     if (!ec) {
                                         do_read();
                                     }
                                 });
    }

    tcp::socket socket_;
    enum {
        max_length = 1024
    };
    char data_[max_length];
};

class server {
public:
    server(boost::asio::io_service &io_service, short port)
            : acceptor_(io_service, tcp::endpoint(tcp::v4(), port)),
              socket_(io_service) {
        do_accept();
    }

private:
    void do_accept() {
        acceptor_.async_accept(socket_,
                               [this](boost::system::error_code ec) {
                                   if (!ec) {
                                       std::make_shared<session>(std::move(socket_))->start();
                                   }

                                   do_accept();
                               });
    }

    tcp::acceptor acceptor_;
    tcp::socket socket_;
};

#include <boost/algorithm//string.hpp>
#include <fstream>

int main(int argc, char *argv[]) {
    std::vector<std::string> serverPoints;

    std::fstream fstream1;

    fstream1.open("rdpServer.txt");
    std::string line;
    std::string key, value;
    while (!fstream1.eof()) {
        std::getline(fstream1, line);
        boost::split(serverPoints, line, [](char c) { return c == '='; });
        key = serverPoints[0];
        value = serverPoints[1];
        value.erase(std::remove(value.begin(), value.end(), '\r'), value.end());
        serverRDPMapT[key] = std::pair<std::string, bool>(value, false);
    }
    try {

        boost::asio::io_service io_service;
        timer = new boost::asio::deadline_timer(io_service, boost::posix_time::seconds(5));
        timer->async_wait(&print);

        server s(io_service, 60000);

        boost::thread thread([&]() {
            io_service.run();
        });
        io_service.run();
    }
    catch (std::exception &e) {
        std::cerr << "Exception: " << e.what() << "\n";
    }

    return 0;
}
