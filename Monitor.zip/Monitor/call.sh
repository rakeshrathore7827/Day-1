
#!/bin/bash

### Print total arguments and their values



{
curl -X POST https://api.twilio.com/2010-04-01/Accounts/ACd07408e984f27982b03ac4f5d814ad41/Calls.json \
--data-urlencode "Url=http://demo.twilio.com/docs/voice.xml" \
--data-urlencode "To=+918700980463" \
--data-urlencode "From=+12075012440" \
-u ACd07408e984f27982b03ac4f5d814ad41:7b2bf2b09b51f62b548dbfaf5759a606



EXCLAMATION_MARK='!'
curl -X POST https://api.twilio.com/2010-04-01/Accounts/ACd07408e984f27982b03ac4f5d814ad41/Messages.json \
	--data-urlencode "Body= $@ InMemoryData crash$EXCLAMATION_MARK" \
	--data-urlencode "From=+12075012440" \
	--data-urlencode "To=+918700980463" \
	-u ACd07408e984f27982b03ac4f5d814ad41:7b2bf2b09b51f62b548dbfaf5759a606


} &> /dev/null
