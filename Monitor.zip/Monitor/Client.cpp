//
// Created by vikram on 1/2/20.
//

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <boost/asio.hpp>
#include <chrono>
#include <fstream>

using boost::asio::ip::tcp;

enum
{
    max_length = 1024
};

struct Details
{
    double time;
    char server[12];
    bool onoff;
    int diff;
    long infrareject;
    long packet;
    int orderType;
};

#include <boost/algorithm//string.hpp>

int main(int argc, char *argv[])
{

    try
    {
        boost::asio::io_service io_service;

        tcp::socket s(io_service);
        tcp::resolver resolver(io_service);
        boost::system::error_code errorCode1;
        boost::asio::connect(s, resolver.resolve({argv[1], "60000"}), errorCode1);

        char *server = argv[2];
        while (1)
        {
            Details details;
            details.onoff = false;
            //details.server = server;
            memcpy(details.server, server, 7);
            details.time = std::chrono::system_clock::now().time_since_epoch().count();
            details.diff = 0;
/*
            system("> data.txt");
            system("pgrep InMem > data.txt");
            std::fstream fstream;
            fstream.open("data.txt");
            std::string data("0");
            fstream >> data;
            if (atoi(data.c_str()) != 0) details.onoff = true;
            fstream.close();

            system("./timediff.sh > data.txt");
            data = "0";
            fstream.open("data.txt");
            fstream >> data;
            details.diff = atoi(data.c_str());
            fstream.close();

            data = "0";
            system("./INFRAREJECT_COUNTER.sh > data.txt");
            fstream.open("data.txt");
            fstream >> data;
            details.infrareject = atol(data.c_str());
            fstream.close();

            data = "0";
            system("./print_data_VMA.sh > data.txt");
            fstream.open("data.txt");
            fstream >> data;
            details.packet = atol(data.c_str());
            fstream.close();

            data = "0";
            system("./OrderType.sh> data.txt");
            fstream.open("data.txt");
            fstream >> data;
            details.orderType = atol(data.c_str());
            fstream.close();
*/
            char request[sizeof(Details)];
            memcpy(request, &details, sizeof(Details));
            size_t request_length = sizeof(Details);
            boost::system::error_code errorCode;
            boost::asio::write(s, boost::asio::buffer(request, request_length), errorCode);
            if (errorCode)
            {
                boost::asio::connect(s, resolver.resolve({argv[1], "60000"}), errorCode);
            }

            sleep(2);
        }

    }
    catch (std::exception &e)
    {
        std::cerr << "Exception: " << e.what() << "\n";
    }

    return 0;
}